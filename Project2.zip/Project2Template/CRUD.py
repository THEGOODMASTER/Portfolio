from pymongo import MongoClient
from bson.objectid import ObjectId
import pprint

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, usrnm, psswd):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        # CREDENTIALS = 'aacuser' 'SNHU1234!'
        USER = usrnm
        PASS = psswd
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30955
        DB = 'aac'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
        	self.database.animals.insert_one(data)
        else:
        	raise Exception("Nothing to save, because data parameter is empty")

    def read(self, data):
        if data is not None:
            return self.database.animals.find(data)
            #return self.database.animals.find(data)
        else:
            print('Nothing to read')
            
# Create method to implement the R in CRUD.
    def readB(self, keyStr, value):
    	 # Check if keyStr is not empty before creating the query
    	query = {} if not keyStr else {keyStr: value}
    
    	# Initialize an empty list to store the results
    	results = []
    
    	# Iterate over the cursor and append each document to the results list
    	for animal in self.collection.find(query):
        	results.append(animal)
    
    	return results

# Update method to implement the U in CRUD.
    def update(self, keyStrFind, valueFind, updateKeystr, updateValue):
    	self.database.animals.update_one({keyStrFind : valueFind}, {'$set':{updateKeystr : updateValue}})
# Delete method to implement the D in CRUD.
    def delete(self, keyStrFind, valueFind):
    	self.database.animals.delete_one({keyStrFind : valueFind})
# Method to ensure that every previous cell works in Jupyter Notebook.
    def testMe():
    	print("TESTING SUCCESFUL")
