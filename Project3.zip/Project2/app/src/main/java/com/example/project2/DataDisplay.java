package com.example.project2;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * Data Display Class
 */

public class DataDisplay extends AppCompatActivity {
    static ListView listView;
    static ArrayList<String> items;
    static ArrayList<String> dates;
    static ListViewAdapter adapter;

    EditText input;
    EditText editText;
    ImageView enter;
    TextView name;
    ImageView edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_data);
        makeToast("Hold Weight To Edit");

        // Only show logged in users data

        listView = findViewById(R.id.listView);
        input = findViewById(R.id.input);
        enter = findViewById(R.id.add);



        items = new ArrayList<>();
        items.add("GOAL" + " 135 " + "lbs");
        dates = new ArrayList<>();
        dates.add(LocalDate.now().toString() + "T" + LocalDateTime.now().getHour() + ":" + LocalDateTime.now().getMinute() + ":" + LocalDateTime.now().getSecond() + " ");

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String name = items.get(i);
                makeToast(name);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                editText = adapter.getView(i,view,adapterView).findViewById(R.id.weightEditor);
                name = adapter.getView(i,view,adapterView).findViewById(R.id.name);
                makeToast("Edit Weight " + items.get(i));
                editText.setVisibility(View.VISIBLE);
                name.setVisibility(View.GONE);
                editText.setText(name.getText());

                edit = adapter.getView(i,view,adapterView).findViewById(R.id.edit);

                edit.setVisibility(View.VISIBLE);

                edit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        editText.setVisibility(View.GONE);
                        name.setVisibility(View.VISIBLE);
                        name.setText(editText.getText());
                        edit.setVisibility(View.GONE);
                    }
                });


                return false;
            }
        });

        adapter = new ListViewAdapter(getApplicationContext(), items, dates);
        listView.setAdapter(adapter);

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = input.getText().toString();
                if (text == null || text.length() == 0){
                    makeToast("Enter an item.");
                }
                else {
                    addItem(text + " lbs");
                    addDate();
                    input.setText("");
                    makeToast("Added: " + text);
                }
            }
        });

    }

    public static void addItem(String item){
        items.add(item);
        listView.setAdapter(adapter);
    }


    public static void addDate(){
        dates.add(LocalDate.now().toString() + "T" + LocalDateTime.now().getHour() + ":" + LocalDateTime.now().getMinute() + ":" + LocalDateTime.now().getSecond() + " ");
    }


    public static void removeItem(int remove){
        items.remove(remove);
        listView.setAdapter(adapter);
    }

    Toast t;

    private void makeToast(String s) {
        if(t != null) t.cancel();
        t = Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT);
        t.show();
    }

}