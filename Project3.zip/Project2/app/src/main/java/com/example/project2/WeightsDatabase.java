package com.example.project2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Database management class
 *  NOT IMPLEMENTED
 */
public class WeightsDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;

    private static final String DATABASE_NAME = "weights.db";

    private static WeightsDatabase instance;

    private WeightsDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static WeightsDatabase getInstance(Context context){
        if (instance == null){
            instance = new WeightsDatabase(context);
        }
        return instance;
    }

    private static final class WeightsTable{
        private static final String TABLE = "weights";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_DATE = "date";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightsTable.TABLE + "(" +
                WeightsTable.COL_WEIGHT + "integer primary key autoincrement, " +
                WeightsTable.COL_DATE + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + WeightsTable.TABLE);
        onCreate(db);
    }

    public String getName(String username){
        String name = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + WeightsTable.TABLE + " WHERE " + WeightsTable.COL_WEIGHT + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{username});

        if (cursor.moveToFirst()){
            name = cursor.getString(1);
        }
        return name;
    }

    public String getWeight(String username){
        String weight = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + WeightsTable.TABLE + " WHERE " + WeightsTable.COL_WEIGHT + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{username});

        if (cursor.moveToFirst()){
            weight = cursor.getString(2);
        }
        return weight;
    }

}
