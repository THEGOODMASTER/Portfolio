package com.example.project2;

public class AuthenticatedUser {
    private String username;

    public AuthenticatedUser(String username){
        this.username = username;
    }

    public String getUsername(){
        return username;
    }
}
